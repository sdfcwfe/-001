import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 解决中文显示问题
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

# 原始数据
data = {
    '指标': [
        '全国城镇调查失业率(%)',
        '31个大城市城镇调查失业率(%)',
        '全国城镇本地户籍劳动力失业率(%)',
        '全国城镇外来户籍劳动力失业率(%)',
        '企业就业人员周平均工作时间(小时)',
        '全国城镇不包含在校生的16—24岁劳动力失业率(%)',
        '全国城镇不包含在校生的25—29岁劳动力失业率(%)',
        '全国城镇不包含在校生的30—59岁劳动力失业率(%)'
    ],
    '2025年2月': [5.4, 5.2, 5.6, 5, 47.1, 16.9, 7.3, 4.3],
    '2025年1月': [5.2, 5.1, 5.4, 4.7, 49.1, 16.1, 6.9, 4],
    '2024年12月': [5.1, 5, 5.3, 4.6, 49, 15.7, 6.6, 3.9],
    '2024年11月': [5, 5, 5.2, 4.6, 48.9, 16.1, 6.7, 3.8],
    '2024年10月': [5, 5, 5.1, 4.8, 48.6, 17.1, 6.8, 3.8],
    '2024年9月': [5.1, 5.1, 5.2, 4.8, 48.8, 17.6, 6.7, 3.9],
    '2024年8月': [5.3, 5.4, 5.4, 4.9, 48.7, 18.8, 6.9, 3.9],
    '2024年7月': [5.2, 5.3, 5.2, 5.1, 48.7, 17.1, 6.5, 3.9],
    '2024年6月': [5, 4.9, 5, 4.8, 48.6, 13.2, 6.4, 4],
    '2024年5月': [5, 4.9, 5.1, 4.7, 48.7, 14.2, 6.6, 4],
    '2024年4月': [5, 5, 5.1, 4.9, 48.5, 14.7, 7.1, 4],
    '2024年3月': [5.2, 5.1, 5.3, 5.1, 48.6, 15.3, 7.2, 4.1],
    '2024年2月': [5.3, 5.1, 5.5, 4.8, 48, 15.3, 6.4, 4.2]
}

# 创建 DataFrame 并处理数据
df = pd.DataFrame(data)
df.columns = [col.replace("年", "").replace("月", "") for col in df.columns]
df = df.set_index('指标').T.reset_index().rename(columns={'index': '日期'})
df['日期'] = pd.to_datetime(df['日期'], format='%Y%m')
df = df.sort_values(by='日期')

# 提取所有指标列并绘制子图
metrics = df.columns[1:]
plt.figure(figsize=(16, 12))
for i, metric in enumerate(metrics):
    plt.subplot(4, 2, i + 1)
    sns.lineplot(data=df, x='日期', y=metric, marker='o')
    plt.title(f'{metric} 趋势')
    plt.xlabel('日期')
    plt.ylabel(metric.split('(')[0])  # 简化纵轴标签
    plt.xticks(rotation=45)
    plt.grid(True)

plt.tight_layout()
plt.show()