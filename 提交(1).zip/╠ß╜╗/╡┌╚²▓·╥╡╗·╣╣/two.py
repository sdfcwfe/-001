import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 直接使用处理后的数据
data = {
    '指标': ['就业人员(万人)', '第一产业就业人员(万人)', '第二产业就业人员(万人)', '第三产业就业人员(万人)'],
    '2024': [73439, np.nan, np.nan, np.nan],
    '2023': [74041, 16882, 21520, 35639],
    '2022': [73351, 17663, 21105, 34583],
    '2021': [74652, 17072, 21712, 35868],
    '2020': [75064, 17715, 21543, 35806],
    '2019': [75447, 18652, 21234, 35561],
    '2018': [75782, 19515, 21356, 34911],
    '2017': [76058, 20295, 21762, 34001],
    '2016': [76245, 20908, 22295, 33042],
    '2015': [76320, 21418, 22644, 32258]
}

df = pd.DataFrame(data)
df = df.replace('', pd.NA).replace(' ', pd.NA)  # 处理空值
df = df.fillna(method='ffill').fillna(method='bfill')  # 双重填充

df.columns = [col.replace("年", "") for col in df.columns]
df = df.set_index('指标').T.reset_index()
df_melt = pd.melt(df, id_vars='index', var_name='指标', value_name='人数（万人）')
df_melt.columns = ['年份', '指标', '人数（万人）']

# 关键修正点：将年份转换为整数
df_melt['年份'] = df_melt['年份'].astype(int)

# 可视化设置
plt.rcParams['font.family'] = 'SimHei'
plt.figure(figsize=(14, 12))

# 1. 趋势分析
plt.subplot(2, 2, 1)
sns.lineplot(data=df_melt, x='年份', y='人数（万人）', hue='指标', marker='o', palette='tab10')
plt.title('各产业就业人数趋势（2015-2024）')
plt.xticks(rotation=45)

# 2. 结构分析（最新年份）
plt.subplot(2, 2, 2)
latest_year = df_melt['年份'].max()
latest_data = df_melt[df_melt['年份'] == latest_year]
plt.pie(latest_data['人数（万人）'], labels=latest_data['指标'],
       autopct='%1.1f%%', colors=['#4e79a7', '#f28e2b', '#e15759', '#76b7b2'])
plt.title(f'{latest_year}年就业结构分布')

# 3. 增长率分析
plt.subplot(2, 2, 3)
df_pivot = df_melt.pivot(index='年份', columns='指标', values='人数（万人）')
growth_rates = df_pivot.pct_change(-1, axis=0) * 100
growth_rates = growth_rates[growth_rates.index >= 2016]  # 直接使用整数比较
sns.lineplot(data=growth_rates, dashes=False, palette='tab10')
plt.axhline(0, color='gray', linestyle='--')
plt.title('各产业就业人数年增长率（%）')
plt.ylabel('增长率 (%)')

# 4. 相关性矩阵
plt.subplot(2, 2, 4)
corr_matrix = df_pivot.corr()
mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', mask=mask, fmt=".2f")
plt.title('产业就业人数相关性矩阵')

plt.tight_layout()
plt.savefig('employment_visualization.png', dpi=300, bbox_inches='tight')
plt.show()