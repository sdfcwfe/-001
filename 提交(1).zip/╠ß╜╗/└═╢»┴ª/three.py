import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['SimHei']

# 创建数据框
data = {
    '季度': ['2021Q1', '2021Q2', '2021Q3', '2022Q1', '2022Q2', '2022Q3', '2023Q1', '2023Q2', '2023Q3', '2024Q1', '2024Q2', '2024Q3'],
    '劳动力(万人)': [17405, 18233, 18303, 17780, 18195, 18205, 18195, 18705, 18774, 18588, 18997, 19014],
    '月均收入(元)': [4190, 4290, 4454, 4436, 4365, 4586, 4504, 4646, 4735, 4853, 4828, 4893]
}

df = pd.DataFrame(data)

# 将零值替换为NaN
df[['劳动力(万人)', '月均收入(元)']] = df[['劳动力(万人)', '月均收入(元)']].replace(0, np.nan)

# 绘制图表
plt.figure(figsize=(12, 6))
plt.plot(df['季度'], df['劳动力(万人)'], label='劳动力(万人)')
plt.plot(df['季度'], df['月均收入(元)'], label='月均收入(元)')
plt.title('农村外出务工劳动力及收入趋势')
plt.xlabel('季度')
plt.ylabel('数值')
plt.legend()
plt.show()