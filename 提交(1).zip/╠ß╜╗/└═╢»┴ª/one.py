import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import lagrange

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['SimHei']

# 创建数据框（含缺失值示例）
# data = {
#     '季度': ['2021Q1', '2021Q2', '2021Q3', '2021Q4', '2022Q1', '2022Q2', '2022Q3', '2022Q4'
#              '2023Q1', '2023Q2', '2023Q3', '2023Q4', '2024Q1', '2024Q2', '2024Q3' '2024Q4'],
#     '劳动力(万人)': [17405,  18233, 18303, np.nan, 17780, 18195, 18205, np.nan,
#                      18195, 18705, 18774, np.nan, 18588, 18997, 19014, np.nan],
#     '月均收入(元)': [4190, 4290,  4454, np.nan, 4436, 4365, 4586, np.nan,
#                      4504, 4646,  4735, np.nan, 4853, 4828, 4893, np.nan],
# }
data = {
    '季度': ['2021Q1', '2021Q2', '2021Q3', '2021Q4', '2022Q1', '2022Q2', '2022Q3', '2022Q4',
             '2023Q1', '2023Q2', '2023Q3', '2023Q4', '2024Q1', '2024Q2', '2024Q3'],
    '劳动力(万人)': [17405, 18233, 18303, np.nan, 17780, 18195, 18205, np.nan,
                     18195, 18705, 18774, np.nan, 18588, 18997, 19014],
    '月均收入(元)': [4190, 4290, 4454, np.nan, 4436, 4365, 4586, np.nan,
                     4504, 4646, 4735, np.nan, 4853, 4828, 4893],
}
df = pd.DataFrame(data)

# 将季度转换为数值坐标（用于插值计算）
df['季度数值'] = np.arange(len(df))  # 生成0-11的连续数值


# 定义拉格朗日插值函数
def lagrange_interpolate(series):
    """对包含缺失值的序列进行拉格朗日插值"""
    known = series.dropna()
    x_known = known.index.values
    y_known = known.values
    poly = lagrange(x_known, y_known)
    return poly(series.index)


# 应用插值
for col in ['劳动力(万人)', '月均收入(元)']:
    df[f'{col}_插值'] = lagrange_interpolate(df[col])

# 可视化结果
plt.figure(figsize=(14, 8))

# 原始数据与插值结果对比
for i, col in enumerate(['劳动力(万人)', '月均收入(元)'], 1):
    plt.subplot(2, 1, i)

    # 绘制原始数据点
    plt.scatter(df['季度'], df[col], c='red', label='原始数据', zorder=3)

    # 绘制插值曲线
    plt.plot(df['季度'], df[f'{col}_插值'], 'b--', label='拉格朗日插值')

    # 标记插值点
    mask = df[col].isna()
    plt.scatter(df[mask]['季度'], df[mask][f'{col}_插值'],
                facecolors='none', edgecolors='green', s=100,
                linewidth=2, label='插值点', zorder=2)

    plt.title(f'{col} - 原始数据与插值对比')
    plt.xlabel('季度')
    plt.ylabel(col.split('(')[0])
    plt.legend()
    plt.grid(alpha=0.4)
    plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# 输出插值结果
print("插值结果数据表：")
print(df[['季度', '劳动力(万人)', '劳动力(万人)_插值', '月均收入(元)', '月均收入(元)_插值']])

# 统计分析
print("\n插值结果统计：")
print(df[['劳动力(万人)_插值', '月均收入(元)_插值']].describe())