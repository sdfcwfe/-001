import pandas as pd
import numpy as np
from pmdarima import auto_arima
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['SimHei']

# 创建示例数据
data = {
    '季度': ['2021Q1', '2021Q2', '2021Q3', '2021Q4', '2022Q1', '2022Q2',
             '2022Q3', '2022Q4', '2023Q1', '2023Q2', '2023Q3', '2023Q4',
             '2024Q1', '2024Q2', '2024Q3'],
    '劳动力(万人)': [17405, 18233, 18303, np.nan, 17780, 18195, 18205, np.nan,
                     18195, 18705, 18774, np.nan, 18588, 18997, 19014],
    '月均收入(元)': [4190, 4290, 4454, np.nan, 4436, 4365, 4586, np.nan,
                     4504, 4646, 4735, np.nan, 4853, 4828, 4893],
}

df = pd.DataFrame(data)


# 修正日期转换逻辑
def convert_quarter(q_str):
    """将季度字符串转换为季度首月日期"""
    year, q = q_str.split('Q')
    month = (int(q) - 1) * 3 + 1  # Q1->1月, Q2->4月, Q3->7月, Q4->10月
    return pd.Timestamp(f"{year}-{month:02d}-01")


df['时间'] = df['季度'].apply(convert_quarter)
df.set_index('时间', inplace=True)


# 优化ARIMA插值函数
def arima_interpolate(series):
    """使用ARIMA进行缺失值插值"""
    # 1. 前向填充初始化
    filled = series.ffill().bfill()

    # 2. 自动选择ARIMA参数
    try:
        model = auto_arima(
            filled.dropna(),
            seasonal=False,
            suppress_warnings=True,
            trace=True,
            error_action='ignore'
        )
        order = model.order
    except:
        order = (1, 1, 1)  # 默认参数

    # 3. 训练模型
    arima_model = ARIMA(filled.dropna(), order=order)
    model_fit = arima_model.fit()

    # 4. 预测缺失值
    missing_dates = series[series.isna()].index
    forecast = model_fit.get_forecast(steps=len(missing_dates))

    # 5. 填充结果
    filled_series = series.copy()
    filled_series.loc[missing_dates] = forecast.predicted_mean.values

    return filled_series


# 应用插值
df['劳动力(万人)_插值'] = arima_interpolate(df['劳动力(万人)'])
df['月均收入(元)_插值'] = arima_interpolate(df['月均收入(元)'])

# 可视化结果
plt.figure(figsize=(14, 7))

# 劳动力趋势
plt.subplot(2, 1, 1)
plt.plot(df.index, df['劳动力(万人)_插值'], 'b-', label='ARIMA插值')
plt.scatter(df[df['劳动力(万人)'].isna()].index,
            df['劳动力(万人)_插值'][df['劳动力(万人)'].isna()],
            edgecolors='r', facecolors='none', s=80, label='插值点')
plt.title('农村外出务工劳动力趋势（ARIMA插值）')
plt.ylabel('人数（万）')
plt.legend()

# 收入趋势
plt.subplot(2, 1, 2)
plt.plot(df.index, df['月均收入(元)_插值'], 'g-', label='ARIMA插值')
plt.scatter(df[df['月均收入(元)'].isna()].index,
            df['月均收入(元)_插值'][df['月均收入(元)'].isna()],
            edgecolors='m', facecolors='none', s=80, label='插值点')
plt.title('外出务工月均收入趋势（ARIMA插值）')
plt.ylabel('收入（元）')
plt.legend()

plt.tight_layout()
plt.show()

# 输出结果
print("最终插值结果：")
print(df[['季度', '劳动力(万人)', '劳动力(万人)_插值',
          '月均收入(元)', '月均收入(元)_插值']])